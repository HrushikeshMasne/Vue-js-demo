<template>
  <div id="app">
    <!--<add-details></add-details>-->
    <show-details></show-details>
  </div>
</template>

<script>
import addDetails from "./components/addDetails.vue"
import showDetails from "./components/showDetails.vue"

export default {
  components:{
    "add-details":addDetails,
    "show-details":showDetails
  }

}
</script>

<style>

</style>
