<template>
  <div>
    <h1>All student details</h1>
    <div v-for="d in details" class="show-div">
         <h5>Student id : {{d.userId}}</h5>
           <h5>Student Name: {{d.title}}</h5>
             <h5>Student City : {{d.body}}</h5>
    </div>
  </div>
</template>

<script>

export default {
data:function(){
  return {
    details:[]       //array for storage
  }
}
,
created(){
   this.$http.get("https://jsonplaceholder.typicode.com/posts").then(function(data){
       this.details= data.body.slice(0,10);
   });
}
}
</script>

<style scoped>
.show-div{
  padding: 10px;
  margin:20px;
  background: #eee;
}
</style>
