<template>
  <div id="add-details">
      <h1>Student Information Form</h1>
 <form v-if="!submitted">
     <div>
      <label>Name : </label>
      <input type="text" v-model.lazy="sname" required />
      <br/>
    </div>
    <div>
      <label>ID : </label>
      <input type="text" v-model.lazy="sid" required /><br/>
    </div>
    <div>
      <label>City : </label>
      <input type="text" v-model.lazy="scity" required />
    </div>
    <button v-on:click.prevent="submit">Save</button>
 </form>

   <div>
     <h3 v-if="submitted">Thanks! Details are saved.</h3>
   </div>

<div id="preview-details">
     <h3>Student name = {{sname}}</h3>
     <p>Student id= {{sid}}</p>
     <p>Student city ={{scity}}</p>
</div>
</div>
</template>

<script>
export default {
   data:function(){
     return {
       sname:"",
       sid:"",
       scity:"",
       submitted:false
     }
   },
   methods:{
     submit:function(){
              this.$http.post("https://jsonplaceholder.typicode.com/posts",{
                 userId: this.sid,
                 title:this.sname,
                 body:this.city
              }).then(function(data){
                console.log(data);
                this.submitted=true;
              });
     }
   }
}
</script>


<style scoped>
form{
  margin:0 auto;
  width:500px;
}
div{
  padding:10px;
}
.add-details{
      text-align: center;
}
input[type=text] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
button{
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 0px 15em;
  border: none;
  cursor: pointer;
  width: 25%;
  opacity: 0.9;
}
h1{
  text-align: center;
}
</style>
